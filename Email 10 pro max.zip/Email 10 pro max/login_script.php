<!DOCTYPE html>
<html lang="en">
<head>
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
<script>
        toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-bottom-left",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        function s_alert()
        {
            toastr.success("Gmail Validation done you can continue now!")
        }
        function e_alert()
        { 
            toastr.error("Invalid Credentials. <br> SMTP Error: Could not authenticate.")
        }
        function i_alert()
        {
            toastr.info("Have Fun vvvv")
        }
        function w_alert()
        {
            toastr.warning("Have Fun vvvv")
        }
    </script>
</head>
<body>
	
</body>
</html>
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
session_start();
require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';


$_SESSION['emailid']=$_POST["email"];
$_SESSION['id']="rahul";
$_SESSION['password']=$_POST["password"];
$_SESSION['cname']=$_POST["cname"];

$mail = new PHPMailer(true);

try {
	//$mail->SMTPDebug = 1;		

	$mail->isSMTP();											
	$mail->Host	 = 'smtp.gmail.com';					
	$mail->SMTPAuth = true;							
	$mail->Username = $_SESSION['emailid'];				
	$mail->Password = $_SESSION['password'];						

    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;						
	$mail->Port=465;

	$mail->setFrom('sguidesigner@gmail.com', 'Name');		
	$mail->addAddress($_SESSION['emailid']);
	//$mail->addAddress('receiver2@gfg.com', 'Name');
	//echo "Hi ra mama";
	$mail->isHTML(true);								
	$mail->Subject = 'Mail Configuration Successful';
	$mail->Body = 'These these system generated mail to test the gmail credentials';
	//$mail->AltBody = 'Body in plain text for non-HTML mail clients';
	$mail->send();
	echo '<script type="text/javascript">s_alert();</script>';
	//echo '<script> alert ("Gmail Validation done you can continue now!!"); </script>';
    //require "filemanger.php";
  
    header("Location:filemanger.php", true, 301);
    exit();
    
	
}
 catch (Exception $e) {
	
	
	//echo '<script type="text/javascript">alert("'.$mail->ErrorInfo.'");</script>';
	//echo '<script type="text/javascript">alert("Invalid Credentials.\n Mailer Error: '.$mail->ErrorInfo.'");</script>';
	//echo '<script> alert ("Invalid Credentials.\n Mailer Error: Username and Password not accepted"); </script>';
	require 'login.php';
    echo '<script type="text/javascript">e_alert();</script>';
    //echo '<script type="text/javascript">location.href = "login.php";</script>';
	//echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

?>









