<?php

    require "common.php";
  ?>
<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mailer</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="assets/css/dummy.css">
  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/css/quill.css">
  <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/css/demo.css" />
  <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />

  <script src="assets/vendor/ckeditor/ckeditor.js"></script>
  <style>
.icons {
            color: red;
        }
.cen{
  align-items: center;
}
.dash{
  border: dashed 2px slategrey;
  margin-left: 20px;
  margin-right: 20px;
  font-size: larger;
  border-radius: 20px;
}
body{
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #c0ffef;
}
a:hover{
    color: rgb(236, 134, 0);
}

input[type=file]::file-selector-button {
  margin-right: 20px;
  border: none;
  background: #FFAE31;
  padding: 10px 20px;
  border-radius: 10px;
  color: #fff;
  cursor: pointer;
  transition: background .2s ease-in-out;
}

input[type=file]::file-selector-button:hover {
  background: #0d45a5;
}
</style>

</head>
<body>

  <header id="header-section">
    <input id="page-nav-toggle" class="main-navigation-toggle" type="checkbox" />
    <label for="page-nav-toggle">
      <svg class="icon--menu-toggle" viewBox="0 0 60 30">
        <g class="icon-group">
          <g class="icon--menu">
            <path d="M 6 0 L 54 0" />
            <path d="M 6 15 L 54 15" />
            <path d="M 6 30 L 54 30" />
          </g>
          <g class="icon--close">
            <path d="M 15 0 L 45 30" />
            <path d="M 15 30 L 45 0" />
          </g>
        </g>
      </svg>
    </label>
    
    <nav class="main-navigation">
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="filemanger.php">File Manager</a></li>
        <li><a href="email.php">Mailer</a></li>
        <li><a href="status.php">Track Status</a></li>
      </ul>
    </nav>
  </header>
<br>
<br>
<br>
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->
      
      
      <!-- Layout container -->
      <div class="layout-page">
        
        <div class="container-sm flex-grow-1 container-p-y">
            <h2 class="fw-bold py-3 mb-4"><strong>Mailer</strong></h2>

            <div class="row">
                <div class="col-lg-12">

                

                    <div class="card">
                        <div class="card-body">
                          <h5 class="card-title">Email Editor</h5>
            
                          <!-- Quill Editor Full -->
                          <!-- <p>Quill editor with full toolset</p> -->
                          <form class="row g-3" action="send.php" method="POST" enctype="multipart/form-data">
                            <div class="col-md-9">
                                <div class="col-md-12">
                                  <div class="form-floating">
                                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter Email">
                                    <label for="email">To</label>
                                  </div>
                                </div>
                              </div>
                                <?php
                                    $dir_path="php/files";
                                    $options="";
                                    if(is_dir($dir_path))
                                    {
                                      $files=opendir($dir_path);
                                      {
                                        if($files)
                                        {
                                          while(($file_name = readdir($files)) != FALSE)
                                          {
                                            if($file_name != '.' && $file_name != '..')
                                            {
                                              $options = $options."<option>$file_name</option>"; 
                                              //echo $file_name."<br>";
                                            }
                                          } 
                                        }
                                      }
                                    }
                                  ?>
                              <div class="col-md-3">
                                <div class="form-floating mb-3">
                                  <select class="form-select" id="fileselect" name="fileselect" aria-label="State">
                                    <option selected value="exit">None</option>
                                    <option value=.$options.><?php echo $options?></option>
                                  </select>
                                  <label for="fileselect">Choose CSV File</label>
                                </div>
                              </div>
                            <div class="col-md-12">
                              <div class="form-floating">
                                <input type="text" class="form-control" id="subject" name="subject" placeholder="Enter Subject">
                                <label for="subject">Subject</label>
                              </div>
                            </div>
                            <div class="col-12">
                                <textarea textarea name="editor" id="editor" rows="10" cols="80"></textarea>
                            </div>
                            <div class="col-12">
                              <center>
                               <input type="file" name="filter" id="filter"/>
                               </center>
            
                            </div>
                            <hr>
                            <div class="text-center">
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#verticalycentered">
                                    Submit Mail
                                  </button>
                                <button type="reset" class="btn btn-secondary">Reset</button>
                                  <div class="modal fade" id="verticalycentered" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered">
                                      <div class="modal-content">
                                        <div class="modal-header">
                                          <h5 class="modal-title">Response Captured Successfully</h5>
                                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                          Your Tacking ID : <strong>15A205</strong>
                                          <br>
                                          Go to Track Status section to track your email status.
                                        </div>
                                        <div class="modal-footer">
                                          <!-- <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button> -->
                                          <button type="submit" class="btn btn-success" name="send">Save changes</button>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                            </div>
                          </form>
                          
                          <!-- End Quill Editor Full -->
            
                        </div>
                      </div>
          
                  </div>

                  
            </div>
             <br> 

       
          <!-- <strong><hr class="my-5" /></strong> -->
          

          

          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
      </div>
      <!-- / Layout page -->
    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
  </div>
  <script src="script.js"></script>
  
  <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script>
    CKEDITOR.replace('editor');
    </script>
    <script src="assets/vendor/js/bootstrap.js"></script>

</body>
</html>
