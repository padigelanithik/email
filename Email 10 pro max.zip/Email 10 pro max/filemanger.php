<?php
    
   require "common.php";
   
   
  ?>
<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mailer</title>
  
  <link rel="stylesheet" href="/assets/css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="assets/css/dummy.css">
  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/css/demo.css" />
  <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />
  <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
<script>
        toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-bottom-left",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        function s_alert()
        {
            toastr.success("Gmail Validation done you can continue now!")
        }
        function e_alert()
        { 
            toastr.error("Have Fun vvvv")
        }
        function i_alert()
        {
            toastr.info("Have Fun vvvv")
        }
        function w_alert()
        {
            toastr.warning("Have Fun vvvv")
        }
    </script>
                    
<style>
.icons {
            color: red;
        }
.cen{
  align-items: center;
}
.dash{
  border: dashed 2px slategrey;
  margin-left: 20px;
  margin-right: 20px;
  font-size: larger;
  border-radius: 20px;
}


/* Import Google font - Poppins */
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap');

*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: "Poppins", sans-serif;
}
body{
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #c0ffef;
}

::selection{
  color: #fff;
  background: #6990F2;
}
.contain{
  margin: 25px;
  width: 350px;
  height: 200px;
  position: relative;
}
.wrapper{
  width: 430px;
  background: #fff;
  border-radius: 5px;
  padding: 30px;
  box-shadow: 7px 7px 12px rgba(0,0,0,0.05);
  margin-left: 50%;
  margin-right: 50%;
}
.wrapper header{
  color: #6990F2;
  font-size: 27px;
  font-weight: 600;
  text-align: center;
}
.wrapper form{
  height: 167px;
  display: flex;
  cursor: pointer;
  margin: 30px 0;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  border-radius: 5px;
  border: 2px dashed #6990F2;
}
form :where(i, p){
  color: #6990F2;
}
form i{
  font-size: 50px;
}
form p{
  margin-top: 15px;
  font-size: 16px;
}

section .row{
  margin-bottom: 10px;
  background: #E9F0FF;
  list-style: none;
  padding: 15px 20px;
  border-radius: 5px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
section .row i{
  color: #6990F2;
  font-size: 30px;
}
section .details span{
  font-size: 14px;
}
.progress-area .row .content{
  width: 100%;
  margin-left: 15px;
}
.progress-area .details{
  display: flex;
  align-items: center;
  margin-bottom: 7px;
  justify-content: space-between;
}
.progress-area .content .progress-bar{
  height: 6px;
  width: 100%;
  margin-bottom: 4px;
  background: #fff;
  border-radius: 30px;
}
.content .progress-bar .progress{
  height: 100%;
  width: 0%;
  background: #6990F2;
  border-radius: inherit;
}
.uploaded-area{
  max-height: 232px;
  overflow-y: scroll;
}
.uploaded-area.onprogress{
  max-height: 150px;
}
.uploaded-area::-webkit-scrollbar{
  width: 0px;
}
.uploaded-area .row .content{
  display: flex;
  align-items: center;
}
.uploaded-area .row .details{
  display: flex;
  margin-left: 15px;
  flex-direction: column;
}
.uploaded-area .row .details .size{
  color: #404040;
  font-size: 11px;
}
.uploaded-area i.fa-check{
  font-size: 16px;
}
.my-5{
  font-weight: 100;
  border: solid 1px #979797f1;
}
a:hover{
    color: rgb(236, 134, 0);
}
.card-body{
  cursor: pointer;
}
</style>
</head>
<body>
<?php
    echo '<script type="text/javascript">s_alert();</script>';
    ?>
  <header id="header-section">
    <input id="page-nav-toggle" class="main-navigation-toggle" type="checkbox" />
    <label for="page-nav-toggle">
      <svg class="icon--menu-toggle" viewBox="0 0 60 30">
        <g class="icon-group">
          <g class="icon--menu">
            <path d="M 6 0 L 54 0" />
            <path d="M 6 15 L 54 15" />
            <path d="M 6 30 L 54 30" />
          </g>
          <g class="icon--close">
            <path d="M 15 0 L 45 30" />
            <path d="M 15 30 L 45 0" />
          </g>
        </g>
      </svg>
    </label>
    
    <nav class="main-navigation">
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="filemanger.php">File Manager</a></li>
        <li><a href="email.php">Mailer</a></li>
        <li><a href="status.php">Track Status</a></li>
      </ul>
    </nav>

  </header>
<br>
<br>
<br>
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->
      
      
      <!-- Layout container -->
      <div class="layout-page">
        
        <div class="container-sm flex-grow-1 container-p-y">
          <div class="row mb-5">
            <h2 class="fw-bold py-3 mb-4"><strong>File Manager</strong></h2>
            <center>
            <div class="col-md-6 col-lg-5 cen" >
              <div class="card mb-1 py-3">
                <form action="email.php" class="dash">
                <div class="card-body">
                  <!-- <h5 class="card-title">Special title treatment</h5>
                  <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                  <a href="javascript:void(0)" class="btn btn-primary">Go somewhere</a> -->
                  
                    <input class="file-input" type="file" style="text-align: center;"
                    accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                     name="file" hidden required>
                    <center><div ><img src="assets/img/icons/brands/upload.svg" style="width: 80px; height:80px;"
                    alt="upload"></div></center>
                    <p class="text-center">Browse File to Upload</p>
                    <h6 class="text-center" style="opacity: 0.7;">Support only CSV and XLXS files</h6>
                    <section class="progress-area icon"></section>
                    <section class="uploaded-area"></section>
                  
                </div>
                
                </form>
                <br>
                
              </div>
            </div>
          </center>
          </div>
          <!-- <strong><hr class="my-5" /></strong> -->
          
        <!-- Content wrapper -->
        <div class="content-wrapper">
          <!-- Content -->

            <!-- <h4 class="fw-bold py-3 mb-4">File Manager</h4> -->

            <!-- <hr class="my-5" /> -->
            
            <!-- Striped Rows -->
            <div class="card">
              <h5 class="card-header">Avaliable Files in Cloud</h5>
              <div class="table-responsive text-nowrap">
                <table class="table table-striped">
                  <thead>
                    <tr>
                      <th>File Name</th>
                      <th>Size</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody class="table-border-bottom-0">
                    
                    <?php
                  
                       $path = "php/files";
                        $files = scandir($path);    
                        foreach($files as $file) {
                          
                          $_SESSION['delete']=$file;
                          if (!in_array($file,array(".",".."))) 
                          { ?>
                            <script>
                              function func(){
                                alert("run babai");
                              }
                            </script>
                            <tr>
                            
                            <td>
                            <img src='assets/img/icons/brands/csv.svg' style='width: 20px; height:20px; color: darkgreen;' alt='csv'>
                            <strong>&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $file; ?></strong></td>
                            <?php $realfile = $path . "/" . $file;?>
                            
                            <td><?php echo filesize($realfile);?> Bytes</td>
                                                       
                            <td>
                            <div class='dropdown'>
                              <button type='button' class='btn p-0 dropdown-toggle hide-arrow' data-bs-toggle='dropdown'>
                                <i class='bx bx-dots-vertical-rounded'></i>
                              </button>
                                <div class='dropdown-menu'>
                                  <!-- <a class='dropdown-item' href='javascript:void(0);'
                                    ><i class='bx bx-edit-alt me-1'></i> Rename</a
                                  >-->
                                  <a class='dropdown-item' href='delete.php'
                                    ><i class='bx bx-trash me-1'></i>Delete</a
                                  > 
                                  <button type="submit" class='dropdown-item' onClick=func()>
                                      <i class='bx bx-trash me-1'></i>Delete
                                  </button>
                                </div>
                              </div>
                            </td>
                            </tr>
                          <?php 
                            }
                          }
                     
                     
                     ?>
                    <tr>

                      <td><img src="assets/img/icons/brands/csv.svg" style="width: 20px; height:20px; color: darkgreen;" alt="csv"> 
                        <strong>&nbsp;&nbsp;&nbsp;&nbsp;Teacher List</strong></td>
                      <td>10 MB</td>
                      
                      <td>
                        <div class="dropdown">
                          <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                            <i class="bx bx-dots-vertical-rounded"></i>
                          </button>
                          <div class="dropdown-menu">
                            <a class="dropdown-item" href="javascript:void(0);"
                              ><i class="bx bx-edit-alt me-1"></i> Rename</a
                            >
                            <a class="dropdown-item" href="javascript:void(0);"
                              ><i class="bx bx-trash me-1"></i> Delete</a
                            >
                          </div>
                        </div>
                      </td>
                    </tr>
                   

                  </tbody>
                </table>
                
              </div>
            </div>
            <!--/ Striped Rows -->

            
          </div>
          <!-- / Content -->

          

          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
      </div>
      <!-- / Layout page -->
    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
  </div>

  <script src="dist/js/script.js"></script>
  <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/js/bootstrap.js"></script>
    
    <script>
        toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-bottom-left",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        function s_alert()
        {
            toastr.success("Gmail Validation done you can continue now!")
        }
        function e_alert()
        { 
            toastr.error("Invalid Credentials.\n Mailer Error: Username and Password not accepted")
        }
        function i_alert()
        {
            toastr.info("Have Fun vvvv")
        }
        function w_alert()
        {
            toastr.warning("Have Fun vvvv")
        }
    </script>

</body>
</html>
<?php
    
    if(!isset($_SESSION['id']))
    {
      header(location:"login.php");
    }
    
   
   
  ?>
