<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="dist/css/toastr.css">
    <script src="dist/js/toastr.min.js"></script>
    <script src="dist/js/toastr.js"></script> -->
    <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
<script>
        toastr.options = {
                "closeButton": true,
                "debug": false,
                "newestOnTop": false,
                "progressBar": true,
                "positionClass": "toast-bottom-left",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "5000",
                "extendedTimeOut": "1000",
                "showEasing": "swing",
                "hideEasing": "linear",
                "showMethod": "fadeIn",
                "hideMethod": "fadeOut"
            }
        function s_alert()
        {
            toastr.success("Have Fun vvvv")
        }
        function e_alert()
        { 
            toastr.error("Have Fun vvvv")
        }
        function i_alert()
        {
            toastr.info("Have Fun vvvv")
        }
        function w_alert()
        {
            toastr.warning("Have Fun vvvv")
        }
    </script>
</head>
<body>
    <?php
    echo '<script type="text/javascript">s_alert();</script>';
    echo '<script type="text/javascript">e_alert();</script>';
    echo '<script type="text/javascript">i_alert();</script>';
    echo '<script type="text/javascript">w_alert();</script>';
    ?>
    
</body>
</html>