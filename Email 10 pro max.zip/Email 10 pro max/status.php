<?php

session_start();
  ?>
<!DOCTYPE html>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mailer</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="assets/css/dummy.css">
  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/css/quill.css">
  <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/css/demo.css" />
  <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />
  
<style>
.icons {
            color: red;
        }
.cen{
  align-items: center;
}
.dash{
  border: dashed 2px slategrey;
  margin-left: 20px;
  margin-right: 20px;
  font-size: larger;
  border-radius: 20px;
}

body{
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #c0ffef;
}
a:hover{
    color: rgb(236, 134, 0);
}
</style>

</head>
<body>

<iframe id="loadarea" style="display:none;"></iframe><br />
<script >
	$("#button1").click(function(){
		document.getElementById('loadarea').src = 'progressbar.php';
	});
	$("#button2").click(function(){
		document.getElementById('loadarea').src = '';
	});
</script>

  <header id="header-section">
    <input id="page-nav-toggle" class="main-navigation-toggle" type="checkbox" />
    <label for="page-nav-toggle">
      <svg class="icon--menu-toggle" viewBox="0 0 60 30">
        <g class="icon-group">
          <g class="icon--menu">
            <path d="M 6 0 L 54 0" />
            <path d="M 6 15 L 54 15" />
            <path d="M 6 30 L 54 30" />
          </g>
          <g class="icon--close">
            <path d="M 15 0 L 45 30" />
            <path d="M 15 30 L 45 0" />
          </g>
        </g>
      </svg>
    </label>
    
    <nav class="main-navigation">
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="filemanger.php">File Manager</a></li>
        <li><a href="email.php">Mailer</a></li>
        <li><a href="status.php">Track Status</a></li>
      </ul>
    </nav>
  </header>
<br>
<br>
<br>
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->
      
      
      <!-- Layout container -->
      <div class="layout-page">
        
        <div class="container-sm flex-grow-1 container-p-y">
            <h2 class="fw-bold py-3 mb-4"><strong>Track Status</strong></h2>

            <div class="row">
                <div class="col-lg-12">

    

                    <div class="card">
                        <div class="card-body">
                          <h5 class="card-title">Email Editor</h5>
            
                          <!-- Quill Editor Full -->
                          <!-- <p>Quill editor with full toolset</p> -->
                            <div class="row g-3">

                            <style>
                              .meter {
                                box-sizing: content-box;
                                height: 10px; /* Can be anything */
                                position: relative;
                                margin: 60px 0 20px 0; /* Just for demo spacing */
                                background: #fff;
                                border-radius: 25px;
                                padding: 10px;
                                box-shadow: inset 0 -1px 1px rgba(255, 255, 255, 0.3);
                              }
                              .meter > span {
                                display: block;
                                height: 100%;
                                border-top-right-radius: 8px;
                                border-bottom-right-radius: 8px;
                                border-top-left-radius: 20px;
                                border-bottom-left-radius: 20px;
                                background-color: rgb(43, 194, 83);
                                background-image: linear-gradient(
                                  center bottom,
                                  rgb(43, 194, 83) 37%,
                                  rgb(84, 240, 84) 69%
                                );
                                box-shadow: inset 0 2px 9px rgba(255, 255, 255, 0.3),
                                  inset 0 -2px 6px rgba(0, 0, 0, 0.4);
                                position: relative;
                                overflow: hidden;
                              }
                              .meter > span:after,
                              .animate > span > span {
                                content: "";
                                position: absolute;
                                top: 0;
                                left: 0;
                                bottom: 0;
                                right: 0;
                                background-image: linear-gradient(
                                  -45deg,
                                  rgba(255, 255, 255, 0.2) 25%,
                                  transparent 25%,
                                  transparent 50%,
                                  rgba(255, 255, 255, 0.2) 50%,
                                  rgba(255, 255, 255, 0.2) 75%,
                                  transparent 75%,
                                  transparent
                                );
                                z-index: 1;
                                background-size: 50px 50px;
                                animation: move 2s linear infinite;
                                border-top-right-radius: 8px;
                                border-bottom-right-radius: 8px;
                                border-top-left-radius: 20px;
                                border-bottom-left-radius: 20px;
                                overflow: hidden;
                              }

                              .animate > span:after {
                                display: none;
                              }


                            </style>
                            <script>
                              $(".meter > span").each(function () {
                                $(this)
                                  .data("origWidth", $(this).width())
                                  .width(0)
                                  .animate(
                                    {
                                      width: $(this).data("origWidth")
                                    },
                                    1200
                                  );
                              });
                              
                            </script>
                      
                                <div class="card">
                                  <div class="card-body">
                                    <div class="row justify-content-center">
                  
                                        <div class="col-xl-2 ml-auto">
                                          <h5 class="card-title">Track ID : <?php echo(rand(10,100)); ?></h5>
                                        </div>
                                        <div class="col-sm-2 ml-auto">
                                           <h5 class="card-title">Date: 15-10-2022</h5>
                                           
                                        </div> 
                                    </div>
                                    <div class="row justify-content-center">
                                        <div class="col-sm-2 ml-auto">
                                           <div id="information" ></div>
                                        </div> 
                                    </div> 
                                    <div class="progress mt-3 meter" id="progressbar">
                                    <!-- <div id="progressbar" style="border:2px solid #ccc; border-radius: 20px; width:100%; heigth:15px;"></div> -->
                                    </div>
                                    <?php


                                      ini_set('max_execution_time', 0); // to get unlimited php script execution time

                                      if(empty($_SESSION['i'])){
                                          $_SESSION['i'] = 0;
                                      }

                                      $total = 100;
                                      //echo $_SESSION['counter'];
                                      for($i=$_SESSION['i'];$i<$total;$i+=1)
                                      {
                                          $_SESSION['i'] = $i;
                                          $percent = intval($i/$total * 100)."%";   
                                        
                                          sleep(1); // Here call your time taking function like sending bulk sms etc.

                                          echo '<script>
                                          parent.document.getElementById("progressbar").innerHTML="<span style=\"width:'.$percent.';background:#37BF00; height:10px;  border-radius: 50px;\">&nbsp;</span>";
                                          parent.document.getElementById("information").innerHTML="<div style=\"text-align:center; font-weight:bold\">'.$percent.' is processed.</div>";</script>';

                                          ob_flush(); 
                                          flush(); 
                                      }
                                      $percent=100;
                                      echo '<script>
                                          parent.document.getElementById("progressbar").innerHTML="<span class="progress-bar bg-success meter" style=\"width:'.$percent.';background:#37BF00; height:10px;  border-radius: 50px;\">&nbsp;</span>";
                                          parent.document.getElementById("information").innerHTML="<div style=\"text-align:center; font-weight:bold\">'.$percent.' is processed.</div>";</script>';

                                      echo '<script>parent.document.getElementById("information").innerHTML="<div style=\"text-align:center; font-weight:bold\">Process completed</div>"</script>';

                                      session_destroy();
                                      ?>
                                    <!-- <center><p><?php echo $_SESSION["percent"]; ?></p></center>  -->
                                    <div id="information" >
                                    


                                    </div>
                                  </div>
                                </div>

                                  <?php
                                  
                                  ?>

                      
                            </div>

                            
                          <!-- End Quill Editor Full -->
            
                        </div>
                      </div>
          
                  </div>

                  
            </div>
             <br> 
          <!-- <strong><hr class="my-5" /></strong> -->
          

          

          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->
      </div>
      <!-- / Layout page -->
    </div>

    <!-- Overlay -->
    <div class="layout-overlay layout-menu-toggle"></div>
  </div>

  <script src="script.js"></script>
  <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="assets/vendor/js/bootstrap.js"></script>
    <script src="assets/vendor/js/quill.js"></script>

</body>
</html>

