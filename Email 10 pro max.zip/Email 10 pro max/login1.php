<?php

   require "common.php";
  ?>
<html>
    <head>
        <link rel="stylesheet" href='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content='width=device-width,intial-scale=1'>
        <style>
            .row_style{
                margin-top:10px;
                margin-left:200px;
            }
        </style>
        <?php
        
        ?>
    </head>
    <body>
       
        <div class='container'>
            <div class='row row_style'>
                <div class='col-xs-6'>
                    <div class='panel panel-primary'>
                        <div class='panel-heading'>
                            <h4>Login Form</h4>
                            
                        </div>
                        <div class='panel-body'>
                            <form method='post' action='login_script.php'>
                                <div class='form-group'>
                                    <label for='email'>Company Name</label><br>
                                    <input type='text' name='cname'/>
                                </div>
                                <div class='form-group'>
                                    <label for='email'>Email Id</label><br>
                                    <input type='email' name='email'/>
                                </div>
                                <div class='form-group'>
                                    <label for='password'>Password</label>
                               
                                 <br>  <input type='password' name='password'/>
                                </div>
                               
                            
                            <button class='btn btn-primary'>login</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </body>
</html>