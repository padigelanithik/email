
<?php
require "common.php";
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
?>
<!-- Coding By CodingNepal - youtube.com/codingnepal -->
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mailer</title>
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="assets/css/dummy.css">
  <!-- Core CSS -->
  <link rel="stylesheet" href="assets/css/quill.css">
  <link rel="stylesheet" href="assets/vendor/css/core.css" class="template-customizer-core-css" />
  <link rel="stylesheet" href="assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
  <link rel="stylesheet" href="assets/css/demo.css" />
  <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />
  <style>
                              .meter {
                                box-sizing: content-box;
                                height: 10px; /* Can be anything */
                                position: relative;
                                margin: 60px 0 20px 0; /* Just for demo spacing */
                                background: #fff;
                                border-radius: 25px;
                                padding: 10px;
                                box-shadow: inset 0 -1px 1px rgba(255, 255, 255, 0.3);
                              }
                              .meter > span {
                                display: block;
                                height: 100%;
                                border-top-right-radius: 8px;
                                border-bottom-right-radius: 8px;
                                border-top-left-radius: 20px;
                                border-bottom-left-radius: 20px;
                                background-color: rgb(43, 194, 83);
                                background-image: linear-gradient(
                                  center bottom,
                                  rgb(43, 194, 83) 37%,
                                  rgb(84, 240, 84) 69%
                                );
                                box-shadow: inset 0 2px 9px rgba(255, 255, 255, 0.3),
                                  inset 0 -2px 6px rgba(0, 0, 0, 0.4);
                                position: relative;
                                overflow: hidden;
                              }
                              .meter > span:after,
                              .animate > span > span {
                                content: "";
                                position: absolute;
                                top: 0;
                                left: 0;
                                bottom: 0;
                                right: 0;
                                background-image: linear-gradient(
                                  -45deg,
                                  rgba(255, 255, 255, 0.2) 25%,
                                  transparent 25%,
                                  transparent 50%,
                                  rgba(255, 255, 255, 0.2) 50%,
                                  rgba(255, 255, 255, 0.2) 75%,
                                  transparent 75%,
                                  transparent
                                );
                                z-index: 1;
                                background-size: 50px 50px;
                                animation: move 2s linear infinite;
                                border-top-right-radius: 8px;
                                border-bottom-right-radius: 8px;
                                border-top-left-radius: 20px;
                                border-bottom-left-radius: 20px;
                                overflow: hidden;
                              }

                              .animate > span:after {
                                display: none;
                              }


                            </style>
                            <script>
                              $(".meter > span").each(function () {
                                $(this)
                                  .data("origWidth", $(this).width())
                                  .width(0)
                                  .animate(
                                    {
                                      width: $(this).data("origWidth")
                                    },
                                    1200
                                  );
                              });
                              
                            </script>
<style>
.icons {
            color: red;
        }
.cen{
  align-items: center;
}
.dash{
  border: dashed 2px slategrey;
  margin-left: 20px;
  margin-right: 20px;
  font-size: larger;
  border-radius: 20px;
}

body{
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #c0ffef;
}
a:hover{
    color: rgb(236, 134, 0);
}
</style>
<iframe id="loadarea" style="display:none;"></iframe><br />
<script >
	$("#button1").click(function(){
		document.getElementById('loadarea').src = 'progressbar.php';
	});
	$("#button2").click(function(){
		document.getElementById('loadarea').src = '';
	});
</script>

</head>
<body>



  <header id="header-section">
    <input id="page-nav-toggle" class="main-navigation-toggle" type="checkbox" />
    <label for="page-nav-toggle">
      <svg class="icon--menu-toggle" viewBox="0 0 60 30">
        <g class="icon-group">
          <g class="icon--menu">
            <path d="M 6 0 L 54 0" />
            <path d="M 6 15 L 54 15" />
            <path d="M 6 30 L 54 30" />
          </g>
          <g class="icon--close">
            <path d="M 15 0 L 45 30" />
            <path d="M 15 30 L 45 0" />
          </g>
        </g>
      </svg>
    </label>
    
    <nav class="main-navigation">
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="filemanger.php">File Manager</a></li>
        <li><a href="email.php">Mailer</a></li>
        <li><a href="status.php">Track Status</a></li>
      </ul>
    </nav>
  </header>
<br>
<br>
<br>
  <div class="layout-wrapper layout-content-navbar">
    <div class="layout-container">
      <!-- Menu -->
      
      
      <!-- Layout container -->
      <div class="layout-page">
        
        <div class="container-sm flex-grow-1 container-p-y">
            <h2 class="fw-bold py-3 mb-4"><strong>Track Status</strong></h2>

            <div class="row">
                <div class="col-lg-12">

    

                    <div class="card">
                        <div class="card-body">
                          <h5 class="card-title">Email Editor</h5>
            
                          <!-- Quill Editor Full -->
                          <!-- <p>Quill editor with full toolset</p> -->
                            <div class="row g-3">

                            
                      
                                <div class="card">
                                <div class="card-body">
                                    <div class="row justify-content-center">
                  
                                        <div class="col-xl-2 ml-auto">
                                          <h5 class="card-title">Track ID : <?php echo(rand(10,100)); ?></h5>
                                        </div>
                                        <div class="col-sm-2 ml-auto">
                                           <h5 class="card-title">Date: 15-10-2022</h5>
                                           
                                        </div> 
                                    </div>
                                    <div class="row justify-content-center">
                                        <div class="col-sm-2 ml-auto">
                                           <div id="information" ></div>
                                        </div> 
                                    </div> 
                                    <div class="progress mt-3 meter" id="progressbar">
                                    <!-- <div id="progressbar" style="border:2px solid #ccc; border-radius: 20px; width:100%; heigth:15px;"></div> -->
                                    </div>
                                </div>
                           </div>
                        </div>
                      </div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>
<?php

try{

    

$email=$_POST['email'];
$subject=$_POST['subject'];
$message=$_POST['editor'];
$mainfile=$_POST['fileselect'];



require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

$total=100;
$mail = new PHPMailer(true);

$mail->isSMTP();                                            
$mail->Host       = 'smtp.gmail.com';                    
$mail->SMTPAuth   = true;                                   
$mail->Username   = $_SESSION['emailid'];                  
$mail->Password   = $_SESSION['password'];                          
$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;           
$mail->Port       = 465;




                                   


ini_set('max_execution_time', 0); // to get unlimited php script execution time

if(empty($_SESSION['i'])){
    $_SESSION['i'] = 0;
}

$total = 100;
//echo $_SESSION['counter'];



//echo $mainfile;
try {  
    if(strcmp($mainfile,"exit")==0)
    {
        
       
        $mail->setFrom($_SESSION['emailid'], $_SESSION['cname']);
        $mail->addAddress($email);    
    
        //$content="Message: ".$message."/n";

        $mail->isHTML(true);                                 
        $mail->Subject = $subject;
        $mail->Body    = $message;
         require  'php/upload_media.php';
        $gfg_folderpath = "php/media/";
        // CHECKING WHETHER PATH IS A DIRECTORY OR NOT
        if (is_dir($gfg_folderpath)) {
            // GETTING INTO DIRECTORY
            $files = opendir($gfg_folderpath); {
                // CHECKING FOR SMOOTH OPENING OF DIRECTORY
                if ($files) {
                    //READING NAMES OF EACH ELEMENT INSIDE THE DIRECTORY
                    while (($gfg_subfolder = readdir($files)) !== FALSE) {
                        // CHECKING FOR FILENAME ERRORS
                        if ($gfg_subfolder != '.' && $gfg_subfolder != '..') {
                            //echo $gfg_folderpath.$gfg_subfolder;
                            // $email->AddAttachment($gfg_folderpath.$gfg_subfolder);
                            echo $gfg_folder;
                            $mail->addAttachment("php/media/$gfg_subfolder", "$gfg_subfolder");
                        }
                            //echo "<br>";
                    }
                }
            }
        }

            
        $mail->send();
        ?>
       
        <?php
        if (is_dir($gfg_folderpath)) {
            // GETTING INTO DIRECTORY
            $files = opendir($gfg_folderpath); {
                // CHECKING FOR SMOOTH OPENING OF DIRECTORY
                if ($files) {
                    //READING NAMES OF EACH ELEMENT INSIDE THE DIRECTORY
                    while (($gfg_subfolder = readdir($files)) !== FALSE) {
                        // CHECKING FOR FILENAME ERRORS
                        if ($gfg_subfolder != '.' && $gfg_subfolder != '..') {
                            //echo $gfg_folderpath.$gfg_subfolder;
                            // $email->AddAttachment($gfg_folderpath.$gfg_subfolder);
                            //$mail->addAttachment("php/media/$gfg_subfolder", "$gfg_subfolder");
                            unlink("php/media/$gfg_subfolder");
                        }
                            //echo "<br>";
                    }
                }
            }
        }
        
        $percent =100;   
       
        sleep(1); // Here call your time taking function like sending bulk sms etc.
    
        echo '<script>
                                          parent.document.getElementById("progressbar").innerHTML="<span class="progress-bar bg-success meter" style=\"width:'.$percent.';background:#37BF00; height:10px;  border-radius: 50px;\">&nbsp;</span>";
                                          parent.document.getElementById("information").innerHTML="<div style=\"text-align:center; font-weight:bold\">'.$percent.' is processed.</div>";</script>';

    
        ob_flush(); 
        flush(); 
        echo '<script> alert ("Custom Mail has been sent") </script>';
       
    }
    else{
        $count=0;
        $file = fopen("php/files/$mainfile", "r");
        
        while (($data = fgetcsv($file)) !== false) {

            $count+=1;
        }
        require  'php/upload_media.php';
        // Closing the file
        $_SESSION['counter']=$count;
        
        fclose($file);
        $_SESSION['counter']=floatval(100)/floatval($count);
        ?>
        
        <?php
        //echo floatval(100)/floatval($count);
        //echo "<br>".$count;
        
            $s=1;
            $file = fopen("php/files/$mainfile", "r");

            // Fetching data from csv file row by row
            $j=0;
            while (($data = fgetcsv($file)) !== false) {

                // HTML tag for placing in row format$arr

                $arr=array();

                echo "<tr>";
                
                if($j==0)
                {
                    $j++;
                    continue;
                }
                foreach ($data as $i) {
                    array_push($arr,$i);
                    //  echo "<td>" . htmlspecialchars($i) 
                    //      . "</td>" ;
                        
                }
                
                echo "<br>";
                echo "</tr> \n";
                //echo $arr[1];
                echo "<br>";
                //echo $arr;
                $i++;
                
                echo "<br>";
                $mail->setFrom($_SESSION['emailid'], $_SESSION['cname']);
                $mail->addAddress($arr[0]);    

                // $content="Message: ".$arr[3]."/n";

                $mail->isHTML(true);                                 
                $mail->Subject = $arr[1];
                $mail->Body    = $arr[2];

                $gfg_folderpath = "php/media/";
                // CHECKING WHETHER PATH IS A DIRECTORY OR NOT
                if (is_dir($gfg_folderpath)) {
                    // GETTING INTO DIRECTORY
                    $files = opendir($gfg_folderpath); {
                        // CHECKING FOR SMOOTH OPENING OF DIRECTORY
                        if ($files) {
                            //READING NAMES OF EACH ELEMENT INSIDE THE DIRECTORY
                            while (($gfg_subfolder = readdir($files)) !== FALSE) {
                                // CHECKING FOR FILENAME ERRORS
                                if ($gfg_subfolder != '.' && $gfg_subfolder != '..') {
                                    //echo $gfg_folderpath.$gfg_subfolder;
                                    // $email->AddAttachment($gfg_folderpath.$gfg_subfolder);
                                    $mail->addAttachment("php/media/$gfg_subfolder", "$gfg_subfolder");
                                }
                                    //echo "<br>";
                            }
                        }
                    }
                }

                $mail->send();
               
                
                
                echo '<script> alert ("Message has been sent") </script>';
                
                $percent = intval($s/$count * 100)."%";   
	
                   sleep(1); // Here call your time taking function like sending bulk sms etc.

                   echo '<script>
                                          parent.document.getElementById("progressbar").innerHTML="<span style=\"width:'.$percent.';background:#37BF00; height:10px;  border-radius: 50px;\">&nbsp;</span>";
                                          parent.document.getElementById("information").innerHTML="<div style=\"text-align:center; font-weight:bold\">'.$percent.' is processed.</div>";</script>';


              ob_flush(); 
              flush(); 
                //echo $s;
                $s++;
            }
            
            sleep(1); // Here call your time taking function like sending bulk sms etc.
            $percent=100;
            echo '<script>
            <center>
            parent.document.getElementById("progressbar").innerHTML="<span class="progress-bar bg-success meter" style=\"width:'.$percent.';background:#37BF00; height:10px;  border-radius: 50px;\">&nbsp;</span>";
            </center>
            parent.document.getElementById("information").innerHTML="<div style=\"text-align:center; font-weight:bold\">'.$percent.' is processed.</div>";</script>';

        echo '<script>parent.document.getElementById("information").innerHTML="<div style=\"text-align:center; font-weight:bold\">Process completed</div>"</script>';

    ob_flush(); 
    flush(); 
    //unlink("php/files/$mainfile");
            if (is_dir($gfg_folderpath)) {
                // GETTING INTO DIRECTORY
                $files = opendir($gfg_folderpath); {
                    // CHECKING FOR SMOOTH OPENING OF DIRECTORY
                    if ($files) {
                        //READING NAMES OF EACH ELEMENT INSIDE THE DIRECTORY
                        while (($gfg_subfolder = readdir($files)) !== FALSE) {
                            // CHECKING FOR FILENAME ERRORS
                            if ($gfg_subfolder != '.' && $gfg_subfolder != '..') {
                                //echo $gfg_folderpath.$gfg_subfolder;
                                // $email->AddAttachment($gfg_folderpath.$gfg_subfolder);
                                //$mail->addAttachment("php/media/$gfg_subfolder", "$gfg_subfolder");
                                unlink("php/media/$gfg_subfolder");
                            }
                                //echo "<br>";
                        }
                    }
                }
            }
            // Closing the file
            fclose($file);
        }
} catch (Exception $e) {
    echo '<script type="text/javascript">alert("Invalid Credentials.\n Mailer Error: '.$mail->ErrorInfo.'");</script>';
    //echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
}
catch (Exception $e) {
    //include 'login.php';
}
?>

