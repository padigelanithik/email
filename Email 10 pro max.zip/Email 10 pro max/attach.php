<?php



require "common.php";


   // $filename=$_FILES['filter']['name'];
   // $tempname=$_FILES['filter']['tmp_name'];
   
   // $loc="php/media/";
   // if(move_uploaded_file($tempname,$loc.$filename))
   // {
   //  echo "filer";
   // }
   // $bit=filesize($loc.$filename);
   // echo $bit;

   $gfg_folderpath = "php/media/";
// CHECKING WHETHER PATH IS A DIRECTORY OR NOT
   if (is_dir($gfg_folderpath)) {
	// GETTING INTO DIRECTORY
	$files = opendir($gfg_folderpath); {
		// CHECKING FOR SMOOTH OPENING OF DIRECTORY
		if ($files) {
			//READING NAMES OF EACH ELEMENT INSIDE THE DIRECTORY
			while (($gfg_subfolder = readdir($files)) !== FALSE) {
				// CHECKING FOR FILENAME ERRORS
            if ($gfg_subfolder != '.' && $gfg_subfolder != '..') {
                  echo $gfg_subfolder;
                  
               
            }
					echo "<br>";
				}
			}
		}
	}


?>